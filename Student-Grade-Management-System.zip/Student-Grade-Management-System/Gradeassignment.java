import java.awt.geom.Ellipse2D;

public class Gradesassigment{

  if (100 >= 90)
      return "A";
    else if (90 >= 80)
      return "B";
    if  (80 >= 70 )
      return "C";
else if (70 >= 60)
      return "D";
   if (60 >= 0)
     return "F";

}

public menu(int grade, String yes, ){
    system.out.println("Would you like to see the report":   );
  
    system.out.println("  ,yes");
     if ( yes == true)
       return System.out.println("it was found");
}