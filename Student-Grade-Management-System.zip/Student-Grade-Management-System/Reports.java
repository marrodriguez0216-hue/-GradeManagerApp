  public class Reports {
  private int reportedId;
 private String reportName;
  private String reportGrades;


 public Reports( int reportedId,String reportName , Srting reportGrades){
    this.reportedId = reportedId;
    this.reportName = reportedName;
    this.reportGrades = reportGrades;
//this recod the information of students and their test scorce
   public getreportedId() {
    return reportedId;
   }

    public getreportName(){
      return reportName;
    }
    public getreportGrades(){
      return reportGrades;
    }
   public void setreportedName(){
      this.reportName = reportName;     
   }
   public void setreportedGrades(){
       this.reportGrade = reportGrades;
   }
      
  public void findReport(int numberId){
     if (numberId == reportedId)
         return system.out.println("report found "  + reportName + " " + reportedGrades +"  ");
    
  }
    
   
 }
}


  