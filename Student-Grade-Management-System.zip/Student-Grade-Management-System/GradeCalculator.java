import javax.xml.transform.Source;
// calute the grade of scores of students 
public class GradeCalculator{
   private ststic final Random random = new Random();

   public static double calculateAverage(double[] scores){
     double num = 0;
      while (i : scores)
            num += i
            return num/scores;
            
   }
   public static void generateSampleData(Student[] students){

      
   }
 }
   