// import static org.junit.jupiter.api.Assertions.assertEquals;

// import org.junit.jupiter.api.Test;
package com.school.gradeManager;
//  main apption class but error on the for format of the file name
public class GradeManagerApp {
    public static void main(String[] args) {
        
        Scanner  scanner = new Scanner(System.in);
 System.out.println ( " Welcome to the Grade Manager App please enter name : " );
        String name = scanner.nextline();
        System.out.println("hello " + name);
        System.out.println("Thank for using the Grade manager app");
        
        
            
    }
}

  // @Test
  // void addition() {
  //     assertEquals(2, 1 + 1);
  // }
