public class Student {
  
  private final int studentId;
  private String firstName;
  private String lastName;
  private  double[] testScores;
  private int numberOfTests = 0;

 public Student(int studentId, String firstName,String lastName,double[] testScores,int numberOftests){
     this.studentId = studentId;
     this.firstName = firstName;
     this.lastName = lastName;
     this.testSorces = testScores;
     this.numbersOfTests = numberOfTests;

       }

  public getstudentId(){
   return studentsId;
  }
  public getfirstName(){
    return firstName;
  }
  public getlastName(){
    return lastName;
  }
  public gettestScores(){
    return testScores;
  }
  public void setfirstName(String firstName){
    this.firstName = firstName;
 }
public void setlastName(String lastName){
    this.lastName = lastName;
}
 public void setTestScores(double[] testSorces){
    this.testScorces = testScores;
    
}
public void setNumberOfTests( int testOfNumber){
    this.numberOfTests = testOfNumber;

}


    

      
    public int gradecalute(){
           int gradeslace = 0;
            int  maxgrade = 100;
              while (i < maxgrade)
                  i++;
                  return grademax; 
                  

    }

    
      
    
  }
  
}
      
     
