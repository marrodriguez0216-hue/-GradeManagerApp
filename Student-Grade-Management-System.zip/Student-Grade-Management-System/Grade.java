import java.awt.geom.Ellipse2D;

public class GradeCalculator {

  private static final Random random = new Random();
  public static double calculateAverage(double[] scores){
         
       if ( random/ scores)
          return score;
          else
          return         ;
  }
  public static void genrateSampleData(student [] students){
         if  (students = so) 
           }
}